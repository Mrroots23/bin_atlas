# BIN Atlas

BIN lookup, issuer analytics and payments education. Flet (Python) app that builds to Android.

## Run on desktop
    pip install -r requirements.txt
    python main.py
    python -m unittest test_engine -v     # 12 engine tests, no network needed

## Build the Android APK
    flet build apk --project "BIN Atlas" --org com.yourname

Requires the Flutter/Android toolchain (`flet doctor` checks it). Flet is pinned to 0.28.3
because newer major versions renamed several APIs (`ft.icons`, `ft.border`, ...).

## Files
- `engine.py` - lookup, cache, providers, analytics, CSV, Luhn explainer (no UI code)
- `main.py`   - Flet UI: Lookup | Banks | Insights | Learn | Saved
- `test_engine.py` - unit tests

## Privacy
Only the first 6 digits are used or stored. Extra digits are dropped immediately.
There are no accounts, no analytics and no tokens stored on the device.

## What changed from the original script
Removed: card generator, Telegram sender (and its plaintext token file), IP "intelligence"
(it looked up the *device's* IP, unrelated to the BIN) and the arbitrary "risk score".

Bugs fixed:
- Luhn check returned "valid" for any number under 13 digits.
- binlist returns `"bank": null`; `d.get("bank", {}).get(...)` crashed silently and skipped the provider.
- HandyAPI's phone dialing code was saved as the currency.
- Database and exports were written to the working directory (read-only on Android) - now app storage.
- Network calls ran on the UI thread and froze the app - now background threads.
- Multi-BIN lookups only displayed the first result - now every BIN gets a card.
- Rate-limit (HTTP 429) and "not found" were indistinguishable from "offline" - now reported separately,
  with a 24h negative cache so providers aren't hammered.
- `.parent` on controls was used to build layouts (unreliable) - rebuilt cleanly.
- Plain-HTTP calls (blocked on modern Android) - everything is HTTPS.

Added: offline mode, 90-day cache refresh, favorites, history, issuer analytics, bank/country search,
CSV export, 5-tab navigation, Luhn step-by-step explainer, network detection from prefix
(Visa, Mastercard, Amex, Discover, JCB, UnionPay, Diners, Mir, Maestro), privacy truncation.
