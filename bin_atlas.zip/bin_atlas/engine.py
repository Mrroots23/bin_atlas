"""BIN Atlas - data engine (no UI dependencies, unit-testable).

Features: BIN lookup with local cache + live providers, offline mode,
favorites, history, issuer analytics, CSV export, Luhn explainer.

Privacy: only the first 6 digits (the BIN/IIN) are ever used or stored.
Anything beyond the 6th digit is discarded immediately.
"""
from __future__ import annotations

import csv
import io
import os
import re
import sqlite3
from contextlib import closing
from datetime import datetime, timedelta

import requests

CACHE_TTL_DAYS = 90          # refresh API-sourced rows older than this
NEG_CACHE_HOURS = 24         # don't re-ask providers about unknown BINs for a day
HTTP_TIMEOUT = 6
USER_AGENT = "BINAtlas/1.0 (educational app)"
SAMPLE_SOURCE = "Sample data"
TS_FMT = "%Y-%m-%d %H:%M:%S"

FIELDS = ["scheme", "type", "brand", "bank", "phone", "url", "country",
          "country_code", "currency", "prepaid", "commercial"]


def default_data_dir() -> str:
    """Writable app storage. On Android Flet exposes FLET_APP_STORAGE_DATA;
    the old script wrote to the working directory, which is read-only there."""
    base = os.environ.get("FLET_APP_STORAGE_DATA") or os.path.join(
        os.path.expanduser("~"), ".bin_atlas")
    os.makedirs(base, exist_ok=True)
    return base


# ----------------------------------------------------------------------
# Pure helpers
# ----------------------------------------------------------------------
def extract_bins(text: str, limit: int = 20) -> list[str]:
    """Return unique 6-digit BINs from free text.

    Separators: comma, Arabic comma, semicolon, newline. Space-separated groups
    are treated as separate BINs only if every group has >= 6 digits, so a
    number typed as '4242 4242 ...' is not split into pieces.
    """
    out: list[str] = []
    for token in re.split(r"[,\u060c;\n]+", text or ""):
        parts = token.split()
        if len(parts) > 1 and all(len(re.sub(r"\D", "", p)) >= 6 for p in parts):
            candidates = parts
        else:
            candidates = [token]
        for cand in candidates:
            digits = re.sub(r"\D", "", cand)
            if len(digits) >= 6 and digits[:6] not in out:
                out.append(digits[:6])
    return out[:limit]


def had_extra_digits(text: str) -> bool:
    """True if any token has more than 8 digits (user pasted a full number)."""
    for token in re.split(r"[,\u060c;\n]+", text or ""):
        parts = token.split()
        if len(parts) > 1 and all(len(re.sub(r"\D", "", p)) >= 6 for p in parts):
            if any(len(re.sub(r"\D", "", p)) > 8 for p in parts):
                return True
        elif len(re.sub(r"\D", "", token)) > 8:
            return True
    return False


def flag_emoji(country_code: str) -> str:
    if not country_code or len(country_code) != 2 or not country_code.isalpha():
        return "\U0001F310"
    return "".join(chr(127397 + ord(c)) for c in country_code.upper())


def detect_scheme(prefix: str) -> tuple[str, str]:
    """Guess the card network from the leading digits (offline fallback).
    Returns (scheme, expected_length_text)."""
    p = re.sub(r"\D", "", prefix or "")
    if not p:
        return "UNKNOWN", ""

    def in_range(k: int, lo: int, hi: int) -> bool:
        return len(p) >= k and lo <= int(p[:k]) <= hi

    if p[:2] in ("34", "37"):
        return "AMEX", "15"
    if in_range(4, 3528, 3589):
        return "JCB", "16-19"
    if in_range(3, 300, 305) or p[:2] in ("36", "38", "39"):
        return "DINERS CLUB", "14-19"
    if p.startswith("6011") or in_range(3, 644, 649) or p.startswith("65"):
        return "DISCOVER", "16-19"
    if p.startswith("62"):
        return "UNIONPAY", "16-19"
    if in_range(4, 2200, 2204):
        return "MIR", "16-19"
    if p[:2] in ("51", "52", "53", "54", "55") or in_range(4, 2221, 2720):
        return "MASTERCARD", "16"
    if p.startswith(("5018", "5020", "5038", "5893", "6304", "6759",
                     "6761", "6762", "6763")):
        return "MAESTRO", "12-19"
    if p.startswith("4"):
        return "VISA", "13, 16 or 19"
    return "UNKNOWN", ""


def luhn_steps(number: str):
    """Explain the Luhn checksum step by step (education only).

    Returns None for fewer than 2 digits (the old script wrongly returned
    "valid" for anything shorter than 13 digits).
    """
    digits = [int(c) for c in re.sub(r"\D", "", number or "")]
    if len(digits) < 2:
        return None
    steps, total = [], 0
    for idx, d in enumerate(reversed(digits)):
        doubled = idx % 2 == 1
        value = d * 2 if doubled else d
        if value > 9:
            value -= 9
        total += value
        steps.append({"digit": d, "doubled": doubled, "value": value})
    steps.reverse()
    return {"steps": steps, "total": total, "valid": total % 10 == 0}


def _up(v, default="N/A") -> str:
    s = str(v).strip() if v not in (None, "") else ""
    return s.upper() if s else default


def _txt(v, default="N/A") -> str:
    s = str(v).strip() if v not in (None, "") else ""
    return s or default


# ----------------------------------------------------------------------
# Engine
# ----------------------------------------------------------------------
class BinEngine:
    def __init__(self, db_path: str | None = None):
        self.db_path = db_path or os.path.join(default_data_dir(), "bin_atlas.db")
        self._init_db()

    # -- storage -------------------------------------------------------
    def _q(self, sql: str, params=(), one: bool = False):
        """Run one statement on a fresh connection (thread-safe, always closed)."""
        with closing(sqlite3.connect(self.db_path, timeout=10)) as conn:
            conn.row_factory = sqlite3.Row
            cur = conn.execute(sql, params)
            result = cur.fetchone() if one else cur.fetchall()
            conn.commit()
        if one:
            return dict(result) if result else None
        return [dict(r) for r in result]

    def _init_db(self):
        self._q("""
            CREATE TABLE IF NOT EXISTS bins (
                bin TEXT PRIMARY KEY,
                scheme TEXT, type TEXT, brand TEXT, bank TEXT,
                phone TEXT, url TEXT, country TEXT, country_code TEXT,
                currency TEXT, prepaid TEXT, commercial TEXT,
                source TEXT, fetched_at TEXT,
                looked_up_at TEXT, lookup_count INTEGER DEFAULT 0,
                favorite INTEGER DEFAULT 0
            )""")
        self._q("CREATE TABLE IF NOT EXISTS misses (bin TEXT PRIMARY KEY, ts TEXT)")
        if self._q("SELECT COUNT(*) AS n FROM bins", one=True)["n"] == 0:
            # Small bundled sample so the app is usable offline on first run.
            # Values are illustrative and NOT verified; live data replaces them.
            seed = [
                ("440393", "VISA", "DEBIT", "PREPAID CLASSIC", "SUTTON BANK", "+18004223641", "http://www.suttonbank.com", "UNITED STATES", "US", "USD", "Yes", "No"),
                ("405542", "VISA", "CREDIT", "CLASSIC", "PT. BANK DBS INDONESIA", "+62211500327", "https://www.dbs.id", "INDONESIA", "ID", "IDR", "No", "No"),
                ("408353", "VISA", "DEBIT", "CLASSIC", "JPMORGAN CHASE BANK, N.A.", "+18009359935", "https://www.chase.com", "UNITED STATES", "US", "USD", "No", "No"),
                ("424242", "VISA", "CREDIT", "CLASSIC", "STRIPE TEST BANK", "+18889262289", "https://stripe.com", "UNITED STATES", "US", "USD", "No", "Yes"),
                ("510510", "MASTERCARD", "CREDIT", "STANDARD", "MASTERCARD TEST ISSUER", "+18006278372", "https://mastercard.com", "UNITED STATES", "US", "USD", "No", "No"),
                ("378282", "AMEX", "CREDIT", "CORPORATE", "AMERICAN EXPRESS COMPANY", "+18005284800", "https://www.americanexpress.com", "UNITED STATES", "US", "USD", "No", "Yes"),
                ("526412", "MASTERCARD", "DEBIT", "PLATINUM", "AL RAJHI BANK", "+966920003344", "https://www.alrajhibank.com.sa", "SAUDI ARABIA", "SA", "SAR", "No", "No"),
            ]
            with closing(sqlite3.connect(self.db_path)) as conn:
                conn.executemany(
                    "INSERT OR IGNORE INTO bins (bin," + ",".join(FIELDS) + ",source) "
                    "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)",
                    [row + (SAMPLE_SOURCE,) for row in seed])
                conn.commit()

    @staticmethod
    def _now() -> str:
        return datetime.now().strftime(TS_FMT)

    def _is_fresh(self, row: dict) -> bool:
        if row.get("source") == SAMPLE_SOURCE or not row.get("fetched_at"):
            return False
        try:
            age = datetime.now() - datetime.strptime(row["fetched_at"], TS_FMT)
        except ValueError:
            return False
        return age < timedelta(days=CACHE_TTL_DAYS)

    def _recent_miss(self, b: str) -> bool:
        row = self._q("SELECT ts FROM misses WHERE bin=?", (b,), one=True)
        if not row:
            return False
        try:
            return datetime.now() - datetime.strptime(row["ts"], TS_FMT) < timedelta(hours=NEG_CACHE_HOURS)
        except ValueError:
            return False

    def _upsert(self, rec: dict):
        b = rec["bin"]
        values = [rec[f] for f in FIELDS]
        if self._q("SELECT 1 AS x FROM bins WHERE bin=?", (b,), one=True):
            self._q("UPDATE bins SET " + ",".join(f"{f}=?" for f in FIELDS) +
                    ",source=?,fetched_at=? WHERE bin=?",
                    values + [rec["source"], self._now(), b])
        else:
            self._q("INSERT INTO bins (bin," + ",".join(FIELDS) + ",source,fetched_at) "
                    "VALUES (?" + ",?" * (len(FIELDS) + 2) + ")",
                    [b] + values + [rec["source"], self._now()])
        self._q("DELETE FROM misses WHERE bin=?", (b,))

    # -- online providers ---------------------------------------------
    def _binlist(self, b: str):
        try:
            r = requests.get(f"https://lookup.binlist.net/{b}",
                             headers={"Accept-Version": "3", "User-Agent": USER_AGENT},
                             timeout=HTTP_TIMEOUT)
        except requests.RequestException:
            return None, "error"
        if r.status_code == 404:
            return None, "notfound"
        if r.status_code == 429:
            return None, "ratelimited"
        if r.status_code != 200:
            return None, "error"
        try:
            d = r.json()
        except ValueError:
            return None, "error"
        # `or {}` fixes a crash in the old code: binlist returns "bank": null
        # for many BINs, and d.get("bank", {}).get(...) raised AttributeError.
        bank = d.get("bank") or {}
        country = d.get("country") or {}
        brand = _up(d.get("brand"))
        prepaid = d.get("prepaid")
        return {
            "bin": b, "source": "binlist.net",
            "scheme": _up(d.get("scheme")), "type": _up(d.get("type")), "brand": brand,
            "bank": _up(bank.get("name")), "phone": _txt(bank.get("phone")),
            "url": _txt(bank.get("url")),
            "country": _up(country.get("name")), "country_code": _up(country.get("alpha2"), ""),
            "currency": _up(country.get("currency")),
            "prepaid": "Yes" if prepaid else ("No" if prepaid is False else "Unknown"),
            "commercial": "Yes" if any(k in brand for k in ("BUSINESS", "CORPORATE", "COMMERCIAL")) else "Unknown",
        }, "ok"

    def _handyapi(self, b: str):
        try:
            r = requests.get(f"https://data.handyapi.com/bin/{b}",
                             headers={"User-Agent": USER_AGENT}, timeout=HTTP_TIMEOUT)
            if r.status_code != 200:
                return None, "ratelimited" if r.status_code == 429 else "error"
            d = r.json()
        except (requests.RequestException, ValueError):
            return None, "error"
        if d.get("Status") != "SUCCESS":
            return None, "notfound"
        country = d.get("Country") or {}
        tier = _up(d.get("CardTier"), "N/A")
        return {
            "bin": b, "source": "handyapi.com",
            "scheme": _up(d.get("Scheme")), "type": _up(d.get("Type")), "brand": tier,
            "bank": _up(d.get("Issuer")), "phone": "N/A", "url": "N/A",
            "country": _up(country.get("Name")), "country_code": _up(country.get("A2"), ""),
            # Old code put the *phone dialing code* (ISD) in the currency field.
            "currency": "N/A",
            "prepaid": "Yes" if "PREPAID" in tier else "Unknown",
            "commercial": "Yes" if any(k in tier for k in ("BUSINESS", "CORPORATE", "COMMERCIAL")) else "Unknown",
        }, "ok"

    def _fetch_online(self, b: str):
        outcomes = []
        for provider in (self._binlist, self._handyapi):
            rec, outcome = provider(b)
            if rec:
                return rec, "ok"
            outcomes.append(outcome)
        if "notfound" in outcomes:
            return None, "notfound"
        if "ratelimited" in outcomes:
            return None, "ratelimited"
        return None, "error"

    # -- public API ---------------------------------------------------
    def lookup(self, bin_code: str, allow_network: bool = True, force_refresh: bool = False) -> dict:
        b = re.sub(r"\D", "", bin_code or "")[:6]      # privacy: drop everything past 6 digits
        scheme, lengths = detect_scheme(b)
        result = {"bin": b, "found": False, "status": "", "message": "",
                  "detected_scheme": scheme, "expected_length": lengths,
                  "flag": flag_emoji("")}
        if len(b) < 6:
            result["message"] = "Enter at least 6 digits."
            return result

        row = self._q("SELECT * FROM bins WHERE bin=?", (b,), one=True)
        need_net = allow_network and (force_refresh or row is None or not self._is_fresh(row))
        message, fetched_live = "", False

        if need_net and not force_refresh and self._recent_miss(b):
            need_net = False
            message = "Online providers had no data for this BIN in the last 24 hours."

        if need_net:
            rec, outcome = self._fetch_online(b)
            if rec:
                self._upsert(rec)
                row = self._q("SELECT * FROM bins WHERE bin=?", (b,), one=True)
                fetched_live = True
            elif outcome == "notfound":
                self._q("INSERT OR REPLACE INTO misses (bin, ts) VALUES (?,?)", (b, self._now()))
                message = "No online provider has data for this BIN."
            elif outcome == "ratelimited":
                message = "Provider rate limit reached. Try again in a while."
            else:
                message = "Could not reach the data providers (offline?)."
        elif not allow_network:
            message = "Offline mode: showing local data only."

        if row:
            self._q("UPDATE bins SET looked_up_at=?, lookup_count=COALESCE(lookup_count,0)+1 WHERE bin=?",
                    (self._now(), b))
            row = self._q("SELECT * FROM bins WHERE bin=?", (b,), one=True)
            if fetched_live:
                status = "live"
            elif row["source"] == SAMPLE_SOURCE:
                status = "sample"
            elif self._is_fresh(row):
                status = "cached"
            else:
                status = "stale"
            result.update(row)
            result.update({"found": True, "status": status, "message": message,
                           "flag": flag_emoji(row.get("country_code", "")),
                           "detected_scheme": scheme, "expected_length": lengths})
        else:
            result["message"] = message or "No data found."
        return result

    def toggle_favorite(self, b: str) -> bool:
        row = self._q("SELECT favorite FROM bins WHERE bin=?", (b,), one=True)
        new = 0 if (row and row["favorite"]) else 1
        self._q("UPDATE bins SET favorite=? WHERE bin=?", (new, b))
        return bool(new)

    def history(self, limit: int = 40) -> list[dict]:
        return self._q("SELECT * FROM bins WHERE looked_up_at IS NOT NULL "
                       "ORDER BY looked_up_at DESC LIMIT ?", (limit,))

    def favorites(self) -> list[dict]:
        return self._q("SELECT * FROM bins WHERE favorite=1 ORDER BY bank, bin")

    def clear_history(self):
        self._q("UPDATE bins SET looked_up_at=NULL, lookup_count=0")

    @staticmethod
    def _like(s: str) -> str:
        return "%" + re.sub(r"[%_]", " ", s.strip().upper()) + "%"

    def search(self, bank: str = "", text: str = "", country: str = "", limit: int = 100) -> list[dict]:
        sql, p = "SELECT * FROM bins WHERE 1=1", []
        if bank.strip():
            sql += " AND UPPER(bank) LIKE ?"
            p.append(self._like(bank))
        if text.strip():
            sql += " AND (UPPER(scheme) LIKE ? OR UPPER(brand) LIKE ? OR UPPER(type) LIKE ?)"
            p += [self._like(text)] * 3
        if country.strip():
            sql += " AND (UPPER(country_code) LIKE ? OR UPPER(country) LIKE ?)"
            p += [self._like(country)] * 2
        sql += " ORDER BY bank, bin LIMIT ?"
        return self._q(sql, p + [limit])

    def analytics(self) -> dict:
        s = self._q("""SELECT COUNT(*) AS total,
                       COALESCE(SUM(prepaid='Yes'),0) AS prepaid,
                       COALESCE(SUM(commercial='Yes'),0) AS commercial,
                       COUNT(DISTINCT CASE WHEN bank NOT IN ('N/A','UNKNOWN') THEN bank END) AS banks,
                       COUNT(DISTINCT CASE WHEN country_code != '' THEN country_code END) AS countries
                       FROM bins""", one=True)

        def group(col: str, limit: int = 8):
            assert col in FIELDS            # column names are whitelisted, never user input
            return [(r["k"], r["n"]) for r in self._q(
                f"SELECT {col} AS k, COUNT(*) AS n FROM bins "
                f"WHERE {col} IS NOT NULL AND {col} NOT IN ('', 'N/A', 'UNKNOWN') "
                f"GROUP BY {col} ORDER BY n DESC, k LIMIT ?", (limit,))]

        s.update({"by_scheme": group("scheme"), "by_type": group("type"),
                  "by_country": group("country_code"), "by_bank": group("bank")})
        return s

    # -- text / export ------------------------------------------------
    @staticmethod
    def format_report(d: dict, note: str = "") -> str:
        lines = [
            f"BIN {d['bin']}",
            f"Network: {d['scheme']} | {d['type']} | {d['brand']}",
            f"Issuer: {d['bank']}",
            f"Country: {d['flag']} {d['country']} ({d['country_code'] or 'N/A'})",
            f"Currency: {d['currency']}",
            f"Prepaid: {d['prepaid']} | Commercial: {d['commercial']}",
            f"Phone: {d['phone']}",
            f"Website: {d['url']}",
            f"Source: {d['source']} ({d['status']})",
        ]
        if note.strip():
            lines.append(f"Note: {note.strip()}")
        return "\n".join(lines)

    @staticmethod
    def to_csv(rows: list[dict]) -> str:
        cols = ["bin", "scheme", "type", "brand", "bank", "country", "country_code",
                "currency", "prepaid", "commercial", "phone", "url", "source", "fetched_at"]
        buf = io.StringIO()
        w = csv.writer(buf)
        w.writerow(cols)
        for r in rows:
            w.writerow([r.get(c, "") for c in cols])
        return buf.getvalue()

    def export_csv_file(self, rows: list[dict]) -> tuple[str, str]:
        """Write a CSV into app storage. Returns (path, csv_text)."""
        text = self.to_csv(rows)
        folder = os.path.join(os.path.dirname(self.db_path), "exports")
        os.makedirs(folder, exist_ok=True)
        path = os.path.join(folder, f"bins_{datetime.now():%Y%m%d_%H%M%S}.csv")
        with open(path, "w", encoding="utf-8", newline="") as f:
            f.write(text)
        return path, text
