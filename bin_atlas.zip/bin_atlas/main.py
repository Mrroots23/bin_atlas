"""BIN Atlas - BIN lookup, issuer analytics and payments education (Flet, Android-ready).

Tabs: Lookup | Banks (search) | Insights (analytics) | Learn (Luhn + BIN anatomy) | Saved
"""
import flet as ft

from engine import (BinEngine, extract_bins, flag_emoji, had_extra_digits,
                    luhn_steps)

# Flet renamed ft.icons -> ft.Icons; support both.
ICONS = getattr(ft, "Icons", None) or ft.icons

BG = "#04141C"
CARD_BG = "#081E29"
BOX_BG = "#0B2532"
CYAN = "#00F0FF"
BORDER = "#134E5E"
WHITE = "#FFFFFF"
MUTED = "#7A9CAE"
GOLD = "#FFD700"
ORANGE = "#FF9800"
GREEN = "#00E676"
RED = "#FF5252"

STATUS_LABEL = {
    "live": ("Live data", GREEN),
    "cached": ("Cached data", CYAN),
    "stale": ("Cached (may be outdated)", ORANGE),
    "sample": ("Bundled sample - unverified", ORANGE),
}
DISCLAIMER = ("Public BIN data can be incomplete or outdated. Information only - "
              "not for identity, credit or compliance decisions.")


# ---------------------------------------------------------------- UI helpers
def card(*controls, title=None, border=BORDER):
    kids = []
    if title:
        kids.append(ft.Text(title, size=14, color=CYAN, weight=ft.FontWeight.W_600))
    kids.extend(controls)
    return ft.Container(bgcolor=CARD_BG, border=ft.border.all(1, border), border_radius=14,
                        padding=16, content=ft.Column(kids, spacing=10))


def capsule(label, value, color=WHITE):
    return ft.Container(
        expand=True, bgcolor=BOX_BG, border=ft.border.all(1, BORDER), border_radius=10,
        padding=ft.padding.symmetric(vertical=8, horizontal=10),
        content=ft.Column([
            ft.Text(label, size=10, color=MUTED),
            ft.Text(str(value), size=13, color=color, weight=ft.FontWeight.W_500, selectable=True),
        ], spacing=2))


def button(text, on_click, primary=False, icon=None, expand=1):
    fg = BG if primary else CYAN
    row = []
    if icon:
        row.append(ft.Icon(icon, color=fg, size=18))
    row.append(ft.Text(text, color=fg, weight=ft.FontWeight.BOLD, size=14))
    return ft.Container(
        content=ft.Row(row, alignment=ft.MainAxisAlignment.CENTER, spacing=6),
        bgcolor=CYAN if primary else BOX_BG,
        border=ft.border.all(1, CYAN if primary else BORDER), border_radius=12,
        padding=ft.padding.symmetric(vertical=12), expand=expand, on_click=on_click, ink=True)


def field(label, **kw):
    return ft.TextField(label=label, border_color=BORDER, focused_border_color=CYAN,
                        border_radius=10, bgcolor=BOX_BG, color=WHITE,
                        label_style=ft.TextStyle(color=MUTED, size=12), **kw)


def header(title, subtitle):
    return ft.Container(
        bgcolor=CARD_BG, border=ft.border.all(1, CYAN), border_radius=14, padding=14,
        content=ft.Column([
            ft.Text(title, size=20, weight=ft.FontWeight.BOLD, color=WHITE),
            ft.Text(subtitle, size=12, color=CYAN),
        ], spacing=2))


def main(page: ft.Page):
    engine = BinEngine()
    page.title = "BIN Atlas"
    page.bgcolor = BG
    page.theme_mode = ft.ThemeMode.DARK
    page.padding = 0

    body = ft.Container(expand=True, padding=12)

    def snack(msg, color=CYAN):
        page.open(ft.SnackBar(ft.Text(msg, color=BG, weight=ft.FontWeight.BOLD), bgcolor=color))

    def copy(text, msg="Copied!"):
        page.set_clipboard(text)
        snack(msg, GREEN)

    def chip(label, on_tap):
        return ft.Container(
            content=ft.Text(label, size=12, color=WHITE), bgcolor=BOX_BG,
            border=ft.border.all(1, BORDER), border_radius=18,
            padding=ft.padding.symmetric(vertical=7, horizontal=14), on_click=on_tap, ink=True)

    def tile(r):
        """Compact list row for a BIN record (search / history / favorites)."""
        flag = ft.Text(r.get("flag") or _flag(r), size=24)
        return ft.Container(
            bgcolor=BOX_BG, border=ft.border.all(1, BORDER), border_radius=10, padding=10,
            ink=True, on_click=lambda _, b=r["bin"]: open_lookup(b),
            content=ft.Row([
                flag,
                ft.Column([
                    ft.Text(f"{r['bin']}  ·  {r['bank'][:30]}", size=13, color=WHITE,
                            weight=ft.FontWeight.W_600),
                    ft.Text(f"{r['scheme']} · {r['type']} · {r['brand']}", size=11, color=MUTED),
                ], spacing=2, expand=True),
                ft.Icon(ICONS.STAR if r.get("favorite") else ICONS.CHEVRON_RIGHT,
                        color=GOLD if r.get("favorite") else MUTED, size=18),
            ], spacing=10))

    def _flag(r):
        return flag_emoji(r.get("country_code", ""))

    # ======================================================== LOOKUP VIEW
    bin_input = field(
        "BIN - first 6-8 digits (separate several with commas)", value="424242",
        input_filter=ft.InputFilter(regex_string=r"[0-9,\u060c;\s]"), max_length=200)
    note_input = field("Optional note for the report", text_size=13)
    offline_switch = ft.Switch(label="Offline mode (local data only)", value=False,
                               active_color=CYAN, label_style=ft.TextStyle(size=12, color=MUTED))
    progress = ft.ProgressBar(color=CYAN, bgcolor=BOX_BG, visible=False)
    results_col = ft.Column(spacing=12)
    recent_row = ft.Row(spacing=8, wrap=True, run_spacing=8)

    def refresh_recent():
        recent_row.controls = [chip(h["bin"], lambda _, b=h["bin"]: quick(b))
                               for h in engine.history(5)]

    def quick(b):
        bin_input.value = b
        run_lookup()

    def result_card(d):
        if not d["found"]:
            guess = ("" if d["detected_scheme"] == "UNKNOWN" else
                     f"Network guessed from prefix: {d['detected_scheme']}"
                     f"{' · length ' + d['expected_length'] if d['expected_length'] else ''}")
            return card(
                ft.Text(f"BIN {d['bin']}", size=20, weight=ft.FontWeight.BOLD, color=WHITE),
                ft.Text(d["message"], color=ORANGE, size=13),
                ft.Text(guess, color=MUTED, size=12, visible=bool(guess)),
                title="No issuer data", border=ORANGE)

        label, color = STATUS_LABEL.get(d["status"], ("", MUTED))
        star = ft.IconButton(ICONS.STAR if d["favorite"] else ICONS.STAR_BORDER,
                             icon_color=GOLD, tooltip="Save to favorites")

        def toggle(_):
            on = engine.toggle_favorite(d["bin"])
            d["favorite"] = int(on)
            star.icon = ICONS.STAR if on else ICONS.STAR_BORDER
            page.update()
        star.on_click = toggle

        def refresh(_):
            progress.visible = True
            page.update()
            def work():
                fresh = engine.lookup(d["bin"], allow_network=True, force_refresh=True)
                idx = next((i for i, c in enumerate(results_col.controls) if c.data == d["bin"]), None)
                if idx is not None:
                    results_col.controls[idx] = result_card(fresh)
                progress.visible = False
                snack(fresh["message"] or "Refreshed", GREEN if fresh["status"] == "live" else ORANGE)
            page.run_thread(work)

        report = engine.format_report(d, note_input.value)
        c = card(
            ft.Row([
                ft.Text(d["flag"], size=44),
                ft.Column([
                    ft.Text(d["bin"], size=24, weight=ft.FontWeight.BOLD, color=WHITE),
                    ft.Text(f"{d['scheme']} · {d['type']} · {d['brand']}", size=12, color=MUTED),
                ], spacing=2, expand=True),
                star,
            ], spacing=10),
            ft.Container(
                content=ft.Text(label, size=11, color=color, weight=ft.FontWeight.BOLD),
                border=ft.border.all(1, color), border_radius=14,
                padding=ft.padding.symmetric(vertical=3, horizontal=10)),
            ft.Text(d["message"], size=11, color=ORANGE, visible=bool(d["message"])),
            ft.Row([capsule("Issuer", d["bank"])]),
            ft.Row([capsule("Country", f"{d['country']} ({d['country_code'] or 'N/A'})"),
                    capsule("Currency", d["currency"])], spacing=8),
            ft.Row([capsule("Prepaid", d["prepaid"]), capsule("Commercial", d["commercial"])], spacing=8),
            ft.Row([capsule("Issuer phone", d["phone"]), capsule("Website", d["url"])], spacing=8),
            ft.Row([capsule("Network by prefix", d["detected_scheme"]),
                    capsule("Typical length", d["expected_length"] or "N/A")], spacing=8),
            ft.Text(f"Source: {d['source']}" + (f" · fetched {d['fetched_at'][:10]}" if d.get("fetched_at") else ""),
                    size=11, color=MUTED),
            ft.Row([
                button("Copy", lambda _: copy(report), icon=ICONS.CONTENT_COPY),
                button("Refresh", refresh, icon=ICONS.REFRESH),
            ], spacing=8),
            border=CYAN)
        c.data = d["bin"]
        return c

    def run_lookup(_=None):
        raw = bin_input.value or ""
        bins = extract_bins(raw)
        if not bins:
            snack("Enter at least 6 digits of a BIN.", ORANGE)
            return
        if had_extra_digits(raw):
            snack("Only the first 6 digits are used; the rest is ignored and never stored.", ORANGE)
        progress.visible = True
        results_col.controls.clear()
        page.update()
        offline = offline_switch.value

        def work():
            try:
                out = [engine.lookup(b, allow_network=not offline) for b in bins]
                results_col.controls = [result_card(d) for d in out]
                if len(out) > 1:
                    found = [d for d in out if d["found"]]
                    text = "\n\n".join(engine.format_report(d, note_input.value) for d in found)
                    results_col.controls.append(
                        button("Copy all reports", lambda _: copy(text), icon=ICONS.CONTENT_COPY))
                refresh_recent()
            except Exception as exc:  # never leave the UI stuck on "loading"
                snack(f"Lookup failed: {exc}", RED)
            finally:
                progress.visible = False
                page.update()
        page.run_thread(work)

    refresh_recent()
    lookup_view = ft.Column([
        header("BIN Lookup", "Issuer, network, country and card type from a BIN"),
        card(
            bin_input, note_input, offline_switch,
            ft.Text("Official test BINs", size=12, color=MUTED),
            ft.Row([chip("Visa 424242", lambda _: quick("424242")),
                    chip("MC 510510", lambda _: quick("510510")),
                    chip("Amex 378282", lambda _: quick("378282"))], spacing=8, wrap=True),
            ft.Text("Recent", size=12, color=MUTED),
            recent_row,
            ft.Row([button("Clear", lambda _: (setattr(bin_input, "value", ""), page.update())),
                    button("Look up", run_lookup, primary=True, icon=ICONS.SEARCH, expand=2)], spacing=10),
            title="Input"),
        progress, results_col,
        ft.Text(DISCLAIMER, size=10, color=MUTED, text_align=ft.TextAlign.CENTER),
    ], spacing=12, scroll=ft.ScrollMode.AUTO, expand=True)

    # ========================================================= BANKS VIEW
    s_bank = field("Bank name (DBS, CHASE, RAJHI...)", text_size=13)
    s_text = field("Network / type / level (VISA, DEBIT, PLATINUM...)", text_size=13)
    s_country = field("Country (US, Saudi...)", text_size=13)
    s_results = ft.Column(spacing=6)
    last_rows = {"rows": []}

    def do_search(_=None):
        rows = engine.search(s_bank.value, s_text.value, s_country.value)
        for r in rows:
            r["flag"] = _flag(r)
        last_rows["rows"] = rows
        s_results.controls = ([ft.Text(f"{len(rows)} BIN(s) found", size=12, color=MUTED)] +
                              [tile(r) for r in rows]) if rows else \
            [ft.Text("No matching BINs in the local database. Look up more BINs to grow it.",
                     color=ORANGE, size=12)]
        page.update()

    def export_results(_):
        rows = last_rows["rows"] or engine.search()
        path, text = engine.export_csv_file(rows)
        copy(text, f"CSV copied ({len(rows)} rows). Also saved: {path}")

    search_view = ft.Column([
        header("Banks & Issuers", "Search the BINs stored on this device"),
        card(s_bank, s_text, s_country,
             ft.Row([button("Search", do_search, primary=True, icon=ICONS.SEARCH),
                     button("Export CSV", export_results, icon=ICONS.DOWNLOAD)], spacing=10)),
        s_results,
    ], spacing=12, scroll=ft.ScrollMode.AUTO, expand=True)

    # ======================================================= INSIGHTS VIEW
    def bars(title, rows, total, label_fn=lambda k: k):
        if not rows:
            return card(ft.Text("No data yet.", size=12, color=MUTED), title=title)
        top = max(n for _, n in rows)
        items = []
        for k, n in rows:
            items.append(ft.Column([
                ft.Text(f"{label_fn(k)}  ·  {n}  ({n * 100 // max(total, 1)}%)", size=12, color=WHITE),
                ft.ProgressBar(value=n / top, color=CYAN, bgcolor=BOX_BG, bar_height=8),
            ], spacing=3))
        return card(*items, title=title)

    def build_insights():
        a = engine.analytics()
        t = max(a["total"], 1)
        return ft.Column([
            header("Issuer Insights", "Analytics over the BINs stored on this device"),
            ft.Row([capsule("BINs stored", a["total"], CYAN), capsule("Issuers", a["banks"], CYAN),
                    capsule("Countries", a["countries"], CYAN)], spacing=8),
            ft.Row([capsule("Prepaid share", f"{a['prepaid'] * 100 // t}%"),
                    capsule("Commercial share", f"{a['commercial'] * 100 // t}%")], spacing=8),
            bars("Card networks", a["by_scheme"], a["total"]),
            bars("Card types", a["by_type"], a["total"]),
            bars("Top countries", a["by_country"], a["total"], lambda c: f"{_flag({'country_code': c})} {c}"),
            bars("Top issuers", a["by_bank"], a["total"], lambda b: b[:28]),
            ft.Text("Shares reflect your local dataset, not the whole market. "
                    "Bundled sample rows are included until replaced by live data.",
                    size=10, color=MUTED),
        ], spacing=12, scroll=ft.ScrollMode.AUTO, expand=True)

    # ========================================================== LEARN VIEW
    luhn_input = field("Digits to check (e.g. the textbook example)", value="79927398713",
                       input_filter=ft.InputFilter(regex_string=r"[0-9\s]"), max_length=23, text_size=14)
    luhn_out = ft.Column(spacing=10)

    def render_luhn():
        res = luhn_steps(luhn_input.value)
        if not res:
            luhn_out.controls = [ft.Text("Enter at least 2 digits.", color=ORANGE, size=12)]
            return
        boxes = []
        for s in res["steps"]:
            boxes.append(ft.Container(
                width=40, padding=4, border_radius=8,
                bgcolor="#103342" if s["doubled"] else BOX_BG,
                border=ft.border.all(1, CYAN if s["doubled"] else BORDER),
                content=ft.Column([
                    ft.Text(str(s["digit"]), size=16, weight=ft.FontWeight.BOLD, color=WHITE),
                    ft.Text(f"x2→{s['value']}" if s["doubled"] else f"{s['value']}", size=10,
                            color=CYAN if s["doubled"] else MUTED),
                ], spacing=0, horizontal_alignment=ft.CrossAxisAlignment.CENTER)))
        ok = res["valid"]
        luhn_out.controls = [
            ft.Row(boxes, wrap=True, spacing=4, run_spacing=4),
            ft.Text("Highlighted digits are doubled (every 2nd digit from the right); "
                    "if a doubled digit is above 9, subtract 9.", size=11, color=MUTED),
            ft.Text(f"Sum = {res['total']}  →  {'divisible by 10: PASSES' if ok else 'not divisible by 10: FAILS'}",
                    size=14, weight=ft.FontWeight.BOLD, color=GREEN if ok else RED),
        ]

    def explain_luhn(_=None):
        render_luhn()
        page.update()

    render_luhn()
    learn_view = ft.Column([
        header("Learn", "How card numbers are structured and checked"),
        card(
            ft.Text("• First digit: Major Industry Identifier (4 = Visa, 5/2 = Mastercard, 3 = Amex/JCB...)\n"
                    "• First 6-8 digits: the BIN / IIN - identifies the issuing bank and product\n"
                    "• Middle digits: the cardholder's account identifier\n"
                    "• Last digit: a Luhn check digit that catches typing mistakes",
                    size=12, color=WHITE),
            ft.Text("The Luhn check only detects typos. It does not mean an account exists or "
                    "has funds - and the BIN alone identifies a bank, never a person.",
                    size=11, color=MUTED),
            title="Anatomy of a card number"),
        card(
            luhn_input,
            button("Explain step by step", explain_luhn, primary=True, icon=ICONS.SCHOOL),
            luhn_out,
            ft.Text("Calculated on your device and never stored.", size=10, color=MUTED),
            title="Luhn checksum explainer"),
        card(
            ft.Text("When testing payments, use the official test numbers from your payment "
                    "provider's documentation (for example Stripe's \"Testing\" page). "
                    "These BINs are safe to look up:", size=12, color=WHITE),
            ft.Row([chip("424242", lambda _: open_lookup("424242")),
                    chip("510510", lambda _: open_lookup("510510")),
                    chip("378282", lambda _: open_lookup("378282"))], spacing=8, wrap=True),
            title="Test numbers"),
    ], spacing=12, scroll=ft.ScrollMode.AUTO, expand=True)

    # ========================================================== SAVED VIEW
    def build_saved():
        favs = engine.favorites()
        hist = engine.history(40)
        for r in favs + hist:
            r["flag"] = _flag(r)

        def clear(_):
            engine.clear_history()
            show(4)
            snack("History cleared (favorites kept).", GREEN)

        def export_all(_):
            path, text = engine.export_csv_file(favs + [h for h in hist if not h["favorite"]])
            copy(text, f"CSV copied. Also saved: {path}")

        return ft.Column([
            header("Saved", "Favorites and lookup history"),
            card(*([tile(r) for r in favs] or [ft.Text("Tap the star on a result to save it here.",
                                                       size=12, color=MUTED)]),
                 title=f"Favorites ({len(favs)})"),
            card(*([tile(r) for r in hist] or [ft.Text("No lookups yet.", size=12, color=MUTED)]),
                 title=f"History ({len(hist)})"),
            ft.Row([button("Export CSV", export_all, icon=ICONS.DOWNLOAD),
                    button("Clear history", clear, icon=ICONS.DELETE_OUTLINE)], spacing=10),
        ], spacing=12, scroll=ft.ScrollMode.AUTO, expand=True)

    # ========================================================= NAVIGATION
    def show(idx):
        page.navigation_bar.selected_index = idx
        if idx == 0:
            body.content = lookup_view
        elif idx == 1:
            body.content = search_view
            if not s_results.controls:
                do_search()
        elif idx == 2:
            body.content = build_insights()
        elif idx == 3:
            body.content = learn_view
        else:
            body.content = build_saved()
        page.update()

    def open_lookup(b):
        bin_input.value = b
        show(0)
        run_lookup()

    page.navigation_bar = ft.NavigationBar(
        bgcolor=CARD_BG, indicator_color=BORDER, selected_index=0,
        on_change=lambda e: show(e.control.selected_index),
        destinations=[
            ft.NavigationBarDestination(icon=ICONS.SEARCH, label="Lookup"),
            ft.NavigationBarDestination(icon=ICONS.ACCOUNT_BALANCE, label="Banks"),
            ft.NavigationBarDestination(icon=ICONS.INSIGHTS, label="Insights"),
            ft.NavigationBarDestination(icon=ICONS.SCHOOL, label="Learn"),
            ft.NavigationBarDestination(icon=ICONS.BOOKMARK, label="Saved"),
        ])

    page.add(ft.SafeArea(body, expand=True))
    show(0)
    run_lookup()


if __name__ == "__main__":
    ft.app(target=main)
