"""Run: python -m unittest test_engine -v   (no network needed)"""
import os, tempfile, unittest
from unittest import mock
import engine as E


class Helpers(unittest.TestCase):
    def test_extract_bins(self):
        self.assertEqual(E.extract_bins("424242, 510510"), ["424242", "510510"])
        self.assertEqual(E.extract_bins("424242 510510"), ["424242", "510510"])
        self.assertEqual(E.extract_bins("4242 4242 4242 4242"), ["424242"])   # one number, not split
        self.assertEqual(E.extract_bins("12345"), [])
        self.assertEqual(E.extract_bins("424242\u060c 424242"), ["424242"])   # Arabic comma + dedupe

    def test_extra_digits_flag(self):
        self.assertTrue(E.had_extra_digits("4242424242424242"))
        self.assertFalse(E.had_extra_digits("424242, 51051012"))

    def test_detect_scheme(self):
        cases = {"424242": "VISA", "510510": "MASTERCARD", "222100": "MASTERCARD",
                 "378282": "AMEX", "601100": "DISCOVER", "353011": "JCB",
                 "620000": "UNIONPAY", "220000": "MIR", "300000": "DINERS CLUB", "999999": "UNKNOWN"}
        for b, s in cases.items():
            self.assertEqual(E.detect_scheme(b)[0], s, b)

    def test_luhn(self):
        self.assertTrue(E.luhn_steps("79927398713")["valid"])     # classic textbook example
        self.assertFalse(E.luhn_steps("79927398710")["valid"])
        self.assertIsNone(E.luhn_steps("7"))
        self.assertEqual(E.luhn_steps("79927398713")["total"], 70)
        # old bug: <13 digits always passed; now a bad short number fails
        self.assertFalse(E.luhn_steps("123456")["valid"])

    def test_flag(self):
        self.assertEqual(E.flag_emoji("US"), "\U0001F1FA\U0001F1F8")
        self.assertEqual(E.flag_emoji(""), "\U0001F310")


class Engine(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.eng = E.BinEngine(os.path.join(self.tmp.name, "t.db"))

    def tearDown(self):
        self.tmp.cleanup()

    def test_seed_and_offline_lookup(self):
        r = self.eng.lookup("424242999999999", allow_network=False)
        self.assertTrue(r["found"]); self.assertEqual(r["bin"], "424242")
        self.assertEqual(r["status"], "sample")
        self.assertIn("Offline", r["message"])

    def test_unknown_offline_falls_back_to_prefix(self):
        r = self.eng.lookup("457173", allow_network=False)
        self.assertFalse(r["found"]); self.assertEqual(r["detected_scheme"], "VISA")

    def test_live_lookup_cached_and_null_bank(self):
        fake = mock.Mock(status_code=200)
        fake.json.return_value = {"scheme": "visa", "type": "debit", "brand": "Classic",
                                  "bank": None, "country": {"name": "Egypt", "alpha2": "EG", "currency": "EGP"},
                                  "prepaid": False}
        with mock.patch("engine.requests.get", return_value=fake) as g:
            r = self.eng.lookup("457173")
            self.assertTrue(r["found"]); self.assertEqual(r["status"], "live")
            self.assertEqual(r["bank"], "N/A"); self.assertEqual(r["currency"], "EGP")
            self.assertEqual(g.call_count, 1)
            r2 = self.eng.lookup("457173")
            self.assertEqual(r2["status"], "cached"); self.assertEqual(g.call_count, 1)  # served from cache

    def test_notfound_negative_cache_and_ratelimit(self):
        nf = mock.Mock(status_code=404)
        with mock.patch("engine.requests.get", return_value=nf) as g:
            r = self.eng.lookup("999999")
            self.assertFalse(r["found"]); calls = g.call_count
            self.eng.lookup("999999")
            self.assertEqual(g.call_count, calls)       # no repeat calls within 24h
        rl = mock.Mock(status_code=429)
        with mock.patch("engine.requests.get", return_value=rl):
            r = self.eng.lookup("888888")
            self.assertIn("rate limit", r["message"])

    def test_network_error_keeps_stale_sample(self):
        import requests
        with mock.patch("engine.requests.get", side_effect=requests.ConnectionError):
            r = self.eng.lookup("408353")
            self.assertTrue(r["found"]); self.assertIn("offline", r["message"].lower())

    def test_favorites_history_search_analytics_csv(self):
        self.eng.lookup("408353", allow_network=False)
        self.assertEqual([h["bin"] for h in self.eng.history()], ["408353"])
        self.assertTrue(self.eng.toggle_favorite("408353"))
        self.assertEqual(len(self.eng.favorites()), 1)
        self.assertFalse(self.eng.toggle_favorite("408353"))
        self.assertEqual(len(self.eng.search(bank="chase")), 1)
        self.assertEqual(len(self.eng.search(country="saudi")), 1)
        self.assertEqual(len(self.eng.search(text="visa")), 4)
        a = self.eng.analytics()
        self.assertEqual(a["total"], 7); self.assertEqual(a["by_scheme"][0], ("VISA", 4))
        path, text = self.eng.export_csv_file(self.eng.search())
        self.assertTrue(os.path.exists(path)); self.assertEqual(len(text.strip().splitlines()), 8)
        self.eng.clear_history(); self.assertEqual(self.eng.history(), [])

    def test_only_six_digits_stored(self):
        self.eng.lookup("4242424242424242", allow_network=False)
        dump = " ".join(str(v) for r in self.eng._q("SELECT * FROM bins") for v in r.values())
        self.assertNotIn("4242424242", dump)


if __name__ == "__main__":
    unittest.main()
